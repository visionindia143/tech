@extends('layouts.frontend')

@section('meta_title', 'Contact Us - PrettyPet')
@section('meta_description', 'Contact PrettyPet for bookings, support and pet care help.')

@section('content')

    @php
        $waNumber = preg_replace('/[^0-9]/', '', $settings['whatsapp_number'] ?? '');
        $waContactUrl = $waNumber
            ? 'https://wa.me/' . $waNumber . '?text=' . urlencode('Hi Pretty Pet, I need help.')
            : route('home');
    @endphp

    <!-- HERO -->

    <div class="page-hero">
        <div class="container">
            <h1>Contact Us</h1>
            <div class="breadcrumb">
                <a href="{{ route('home') }}">Home</a> / Contact
            </div>
        </div>
    </div>

    </div>

    <!-- MAIN -->

    <section class="contact-section">
        <div class="container">


            <div class="contact-grid">

                <!-- CONTACT CARDS -->
                <div class="contact-cards">

                    <!-- WhatsApp FIRST -->
                    <a href="{{ $waContactUrl }}" target="_blank" class="contact-card whatsapp">
                        <i class="fab fa-whatsapp"></i>
                        <div>
                            <h4>WhatsApp</h4>
                            <p>Chat instantly with our team</p>
                        </div>
                    </a>

                    <a href="tel:{{ $settings['site_phone'] }}" class="contact-card call-card">
                        <i class="fas fa-phone"></i>
                        <div>
                            <h4>Call Us</h4>
                            <p>{{ $settings['site_phone'] }}</p>
                        </div>
                    </a>

                    <a href="mailto:{{ $settings['site_email'] }}" class="contact-card">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <h4>Email</h4>
                            <p>{{ $settings['site_email'] }}</p>
                        </div>
                    </a>

                    <div class="contact-card">
                        <i class="fas fa-clock"></i>
                        <div>
                            <h4>Working Hours</h4>
                            <p>9 AM – 8 PM (Mon–Sat)</p>
                        </div>
                    </div>

                </div>

                <!-- INFO BOX -->
                <div class="contact-info-box">
                    <h3>Fastest Support 🚀</h3>
                    <p>
                        WhatsApp is the quickest way to reach us.
                        Share your pet details and our team will guide you instantly.
                    </p>

                    <a href="{{ $waContactUrl }}" class="btn-wa big" target="_blank">
                        Start WhatsApp Chat
                    </a>
                </div>

            </div>

        </div>


    </section>



@endsection

@section('styles')

    <style>
        /* HERO */
        .contact-hero {
            background: linear-gradient(135deg, #2D1B69, #FF6B35);
            padding: 70px 0;
            color: #fff;
        }

        .hero-content {
            max-width: 600px;
        }

        .hero-badge {
            display: inline-flex;
            gap: 8px;
            padding: 6px 12px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 20px;
            font-size: 0.8rem;
            margin-bottom: 15px;
        }

        .contact-hero h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }

        .contact-hero p {
            opacity: 0.9;
            margin-bottom: 20px;
        }

        .hero-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        /* BUTTONS */
        .btn-wa {
            background: #25D366;
            color: #fff;
            padding: 12px 18px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
        }

        .btn-wa.big {
            display: block;
            text-align: center;
            margin-top: 15px;
        }

        .btn-call {
            background: #fff;
            color: #000;
            padding: 12px 18px;
            border-radius: 10px;
            text-decoration: none;
        }

        /* SECTION */
        .contact-section {
            padding: 50px 0;
            background: #f8fafc;
        }

        /* GRID */
        .contact-grid {
            display: grid;
            grid-template-columns: 1fr 350px;
            gap: 25px;
        }

        /* CARDS */
        .contact-cards {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .contact-card {
            background: #fff;
            padding: 18px;
            border-radius: 12px;
            display: flex;
            gap: 12px;
            align-items: center;
            border: 1px solid #eee;
        }

        .contact-card i {
            font-size: 20px;
        }

        .contact-card.whatsapp {
            border: 2px solid #25D366;
        }

        /* SIDE BOX */
        .contact-info-box {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
        }

        /* FLOATING BUTTON */
        .floating-wa {
            position: fixed;
            bottom: 15px;
            left: 10px;
            right: 10px;
            background: #25D366;
            color: #fff;
            text-align: center;
            padding: 14px;
            border-radius: 10px;
            z-index: 999;
            display: none;
        }

        /* MOBILE */
        @media(max-width:768px) {

            .contact-grid {
                grid-template-columns: 1fr;
            }

            .contact-cards {
                grid-template-columns: 1fr;
            }

            .contact-hero h1 {
                font-size: 2rem;
            }

            .floating-wa {
                display: block;
            }
        }
    </style>

@endsection
