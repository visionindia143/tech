@extends('layouts.frontend')

@section('content')

    {{-- HERO SLIDER --}}
    @if ($sliders->count())
        <section class="hero">
            <div class="hero-slider" id="heroSlider">
                @foreach ($sliders as $slider)
                    <div class="hero-slide">
                        <div class="hero-slide-bg" style="background-image: url('{{ $slider->image_url }}')"></div>
                        <div class="hero-slide-content">
                            <h1>{{ $slider->title }}</h1>
                            @if ($slider->subtitle)
                                <p>{{ $slider->subtitle }}</p>
                            @endif
                            @if ($slider->button_text)
                                <a href="{{ $slider->button_link ?? '#' }}" class="btn btn-primary">
                                    {{ $slider->button_text }} <i class="fas fa-arrow-right"></i>
                                </a>
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>
            @if ($sliders->count() > 1)
                <div class="hero-nav">
                    @foreach ($sliders as $i => $slider)
                        <button class="hero-dot {{ $i === 0 ? 'active' : '' }}"
                            onclick="goToSlide({{ $i }})"></button>
                    @endforeach
                </div>
            @endif
        </section>
    @endif

    {{-- PET GALLERY --}}
    @if ($galleries->count())
        <section class="section">
            <div class="container">
                <div class="section-header fade-up">
                    <span class="section-badge"><i class="fas fa-camera"></i> Our Friends</span>
                    <h2>Meet Our Adorable Pets</h2>
                    <p>Browse our gallery of lovable companions waiting to brighten your day</p>
                </div>
                <div class="gallery-slider-wrap">
                    <div class="gallery-slider" id="gallerySlider">
                        @foreach ($galleries as $gallery)
                            <div class="gallery-slide">
                                <div class="gallery-card fade-up" data-title="{{ $gallery->title }}"
                                    data-breed="{{ $gallery->breed }}">
                                    <img src="{{ $gallery->image_url }}" alt="{{ $gallery->title }}" loading="lazy">
                                    <div class="gallery-card-overlay">
                                        <h4>{{ $gallery->title }}</h4>
                                        @if ($gallery->breed)
                                            <span>{{ $gallery->breed }}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>

                    @if ($galleries->count() > 1)
                        <button class="gallery-slider-nav gallery-slider-prev" type="button"
                            onclick="moveGallerySlider(-1)"><i class="fas fa-chevron-left"></i></button>
                        <button class="gallery-slider-nav gallery-slider-next" type="button"
                            onclick="moveGallerySlider(1)"><i class="fas fa-chevron-right"></i></button>
                    @endif
                </div>
            </div>
        </section>
    @endif



    {{-- PET CARE SERVICES --}}
    @if ($services->count())
        <section class="section" style="background: var(--clr-light-gray);">
            <div class="container">
                <div class="section-header fade-up">
                    <span class="section-badge"><i class="fas fa-heart"></i> What We Offer</span>
                    <h2>Premium Pet Care Services</h2>
                    <p>Everything your pet needs under one roof — from grooming to medical care</p>
                </div>
                <div class="services-grid">
                    @foreach ($services as $service)
                        <div class="service-card fade-up">
                            <div class="service-icon">
                                @if ($service->icon)
                                    <i class="{{ $service->icon }}"></i>
                                @else
                                    <i class="fas fa-paw"></i>
                                @endif
                            </div>
                            <h3>{{ $service->title }}</h3>
                            <p>{{ $service->short_description }}</p>
                            @if ($service->price)
                                <div class="service-price">From ₹{{ number_format($service->price) }}</div>
                            @endif
                            <a href="{{ route('service.show', $service->slug) }}"
                                style="display:inline-block;margin-top:12px;color:var(--clr-primary);font-weight:600;font-size:0.88rem;">
                                Learn More <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    @endforeach
                </div>
            </div>
        </section>
    @endif

    {{-- AVAILABLE CITIES --}}
    @if ($cities->count())
        <section class="section">
            <div class="container">
                <div class="section-header fade-up">
                    <span class="section-badge"><i class="fas fa-map-marker-alt"></i> Locations</span>
                    <h2>Available in Your City</h2>
                    <p>We're expanding to bring the best pet care closer to you</p>
                </div>
                <div class="cities-grid">
                    @foreach ($cities as $city)
                        <a href="{{ route('city.detail', $city->slug) }}" class="city-card fade-up"
                            style="text-decoration:none;color:inherit;display:block;">
                            @if ($city->image)
                                <img src="{{ $city->image_url }}" alt="{{ $city->name }}" loading="lazy">
                            @else
                                <div
                                    style="width:100%;height:100%;background:linear-gradient(135deg,var(--clr-primary),var(--clr-accent))">
                                </div>
                            @endif
                            <div class="city-card-content">
                                <h3>{{ $city->name }}</h3>
                                @if ($city->description)
                                    <p>{{ Str::limit($city->description, 60) }}</p>
                                @endif
                            </div>
                        </a>
                    @endforeach
                </div>
            </div>
        </section>
    @endif

    {{-- CTA SECTION --}}
    <section class="section" style="padding-bottom: 0;">
        <div class="cta-section fade-up">
            <h2>Give Your Pet the Best Care</h2>
            <p>Book a vaccination appointment today and keep your furry friend healthy and happy</p>
            <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap;">
                <a href="{{ route('vaccination') }}" class="btn btn-primary">
                    <i class="fas fa-syringe"></i> Book Vaccination
                </a>
                <a href="{{ route('adoption.index') }}" class="btn btn-white">
                    <i class="fas fa-heart"></i> Adopt a Pet
                </a>
                <a href="{{ route('contact') }}" class="btn btn-white">
                    <i class="fas fa-phone"></i> Contact Us
                </a>
            </div>
        </div>
    </section>

    {{-- FEATURED BLOGS --}}
    @if ($blogs->count())
        <section class="section">
            <div class="container">
                <div class="section-header fade-up">
                    <span class="section-badge"><i class="fas fa-newspaper"></i> Our Blog</span>
                    <h2>Pet Care Tips & Stories</h2>
                    <p>Expert advice and heartwarming stories from the world of pets</p>
                </div>

                <div class="blog-slider-wrap">
                    <div class="blog-slider" id="blogSlider">
                        @foreach ($blogs as $blog)
                            <div class="blog-slide">
                                <a href="{{ route('blog.detail', $blog->slug) }}" class="blog-card">
                                    <div class="blog-card-img">
                                        <img src="{{ $blog->image_url }}" alt="{{ $blog->title }}">
                                    </div>
                                    <div class="blog-card-body">
                                        <div class="blog-card-date">{{ $blog->created_at->format('M d, Y') }}</div>
                                        <h3>{{ $blog->title }}</h3>
                                        <p>{{ $blog->excerpt }}</p>
                                        <span class="blog-card-link">Read More →</span>
                                    </div>
                                </a>
                            </div>
                        @endforeach
                    </div>

                    <button class="blog-slider-nav blog-slider-prev" onclick="moveBlogSlider(-1)">‹</button>
                    <button class="blog-slider-nav blog-slider-next" onclick="moveBlogSlider(1)">›</button>
                </div>
                <div style="text-align:center;margin-top:40px;">
                    <a href="{{ route('blogs') }}" class="btn btn-outline">View All Posts <i
                            class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </section>
    @endif








@section('scripts')

    <script>
        /* ================= HERO SLIDER ================= */

        (function() {
            let currentSlide = 0;
            const slider = document.getElementById('heroSlider');
            const dots = document.querySelectorAll('.hero-dot');
            const totalSlides = {{ $sliders->count() }};

            if (!slider || totalSlides <= 1) return;

            function goToSlide(index) {
                currentSlide = index;

                slider.style.transform = `translateX(-${index * 100}%)`;

                dots.forEach((dot, i) => {
                    dot.classList.toggle('active', i === index);
                });
            }

            // auto slide
            setInterval(() => {
                goToSlide((currentSlide + 1) % totalSlides);
            }, 5500);

            // global (dot click ke liye)
            window.goToSlide = goToSlide;
        })();
    </script>
    <script>
        /* ================= BLOG SLIDER ================= */

        (function() {

            const blogSlider = document.getElementById('blogSlider');
            if (!blogSlider) return;

            let blogIndex = 0;

            function getVisibleCount() {
                if (window.innerWidth >= 992) return 3;
                if (window.innerWidth >= 600) return 2;
                return 1;
            }

            function moveBlogSlider(dir) {
                const slides = blogSlider.querySelectorAll('.blog-slide');
                const total = slides.length;
                const visible = getVisibleCount();

                blogIndex += dir;

                if (blogIndex < 0) blogIndex = total - visible;
                if (blogIndex > total - visible) blogIndex = 0;

                const movePercent = blogIndex * (100 / visible);
                blogSlider.style.transform = `translateX(-${movePercent}%)`;
            }

            /* AUTO SLIDE */
            setInterval(() => {
                moveBlogSlider(1);
            }, 3000);

            /* RESIZE FIX */
            window.addEventListener('resize', () => {
                moveBlogSlider(0);
            });

            /* GLOBAL (buttons ke liye) */
            window.moveBlogSlider = moveBlogSlider;

        })();
    </script>

    <script>
        // Gallery slider
        const gallerySlider = document.getElementById('gallerySlider');
        let gallerySlideIndex = 0;
        const gallerySlides = gallerySlider ? gallerySlider.querySelectorAll('.gallery-slide') : [];

        function moveGallerySlider(direction) {
            if (!gallerySlider || !gallerySlides.length) return;
            const visibleCount = window.innerWidth >= 1200 ? 4 : (window.innerWidth >= 768 ? 3 : 1);
            const maxIndex = Math.max(0, gallerySlides.length - visibleCount);
            gallerySlideIndex = Math.min(maxIndex, Math.max(0, gallerySlideIndex + direction));
            gallerySlider.style.transform = `translateX(-${gallerySlideIndex * (100 / visibleCount)}%)`;
        }

        if (gallerySlider && gallerySlides.length > 1) {
            window.addEventListener('resize', () => moveGallerySlider(0));
        }

        // Gallery lightbox
        const galleryItems = Array.from(document.querySelectorAll('.gallery-card'));
        const lightbox = document.getElementById('galleryLightbox');
        const lightboxImg = document.getElementById('galleryLightboxImg');
        const lightboxTitle = document.getElementById('galleryLightboxTitle');
        const lightboxMeta = document.getElementById('galleryLightboxMeta');
        let currentGalleryIndex = 0;

        function openGalleryLightbox(index) {
            if (!lightbox || !lightboxImg) return;
            currentGalleryIndex = index;
            renderGalleryLightbox();
            lightbox.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function renderGalleryLightbox() {
            const item = galleryItems[currentGalleryIndex];
            if (!item || !lightboxImg) return;
            const img = item.querySelector('img');
            const title = item.dataset.title || '';
            const breed = item.dataset.breed || '';
            lightboxImg.src = img ? img.src : '';
            lightboxImg.alt = title;
            if (lightboxTitle) lightboxTitle.textContent = title;
            if (lightboxMeta) lightboxMeta.textContent = breed;
        }

        function closeGalleryLightbox() {
            if (!lightbox) return;
            lightbox.classList.remove('active');
            document.body.style.overflow = '';
        }

        function navigateGallery(direction) {
            if (!galleryItems.length) return;
            currentGalleryIndex = (currentGalleryIndex + direction + galleryItems.length) % galleryItems.length;
            renderGalleryLightbox();
        }

        galleryItems.forEach((item, index) => {
            item.addEventListener('click', () => openGalleryLightbox(index));
        });

        window.openGalleryLightbox = openGalleryLightbox;
        window.closeGalleryLightbox = closeGalleryLightbox;
        window.navigateGallery = navigateGallery;
        window.moveGallerySlider = moveGallerySlider;
    </script>


    <style>
        /* ===== BLOG SLIDER WRAP ===== */
        .blog-slider-wrap {
            position: relative;
            overflow: hidden;
            border-radius: 16px;
        }

        /* ===== SLIDER TRACK ===== */
        .blog-slider {
            display: flex;
            gap: 20px;
            transition: transform 0.5s ease;
            will-change: transform;
        }

        /* ===== EACH SLIDE ===== */
        .blog-slide {
            flex: 0 0 calc(33.333% - 14px);
            /* 3 cards */
        }

        /* ===== BLOG CARD ===== */
        .blog-card {
            display: block;
            background: #fff;
            border-radius: 16px;
            overflow: hidden;
            border: 1px solid #eee;
            text-decoration: none;
            color: inherit;
            transition: all 0.3s ease;
        }

        /* hover effect */
        .blog-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 12px 28px rgba(0, 0, 0, 0.08);
        }

        /* ===== IMAGE ===== */
        .blog-card-img {
            width: 100%;
            height: 200px;
            overflow: hidden;
        }

        .blog-card-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.4s ease;
        }

        /* zoom effect */
        .blog-card:hover .blog-card-img img {
            transform: scale(1.05);
        }

        /* ===== CONTENT ===== */
        .blog-card-body {
            padding: 16px;
        }

        .blog-card-date {
            font-size: 12px;
            color: #999;
            margin-bottom: 6px;
        }

        .blog-card-body h3 {
            font-size: 18px;
            margin-bottom: 8px;
        }

        .blog-card-body p {
            font-size: 14px;
            color: #666;
        }

        .blog-card-link {
            display: inline-block;
            margin-top: 10px;
            font-size: 14px;
            color: #ff6b35;
            font-weight: 600;
        }

        /* ===== ARROWS ===== */
        .blog-slider-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 42px;
            height: 42px;
            border-radius: 50%;
            border: none;
            background: #fff;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            z-index: 2;
            transition: 0.3s;
        }

        .blog-slider-nav:hover {
            background: #ff6b35;
            color: #fff;
        }

        .blog-slider-prev {
            left: 10px;
        }

        .blog-slider-next {
            right: 10px;
        }

        /* ===== RESPONSIVE ===== */

        @media (max-width: 991px) {
            .blog-slide {
                flex: 0 0 100%;
            }
        }

        @media (max-width: 600px) {
            .blog-slide {
                flex: 0 0 100%;
                /* 1 card */
            }
        }
    </style>

    <style>
        .gallery-slider-wrap {
            position: relative;
            overflow: hidden;
            border-radius: var(--radius-lg);
        }

        .gallery-slider {
            display: flex;
            gap: 20px;
            transition: transform 0.55s ease;
            will-change: transform;
        }

        .gallery-slide {
            flex: 0 0 calc(25% - 15px);
            min-width: 0;
        }

        .gallery-slider-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 42px;
            height: 42px;
            border: none;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.95);
            box-shadow: var(--shadow-md);
            color: var(--clr-secondary);
            cursor: pointer;
            z-index: 3;
        }

        .gallery-slider-prev {
            left: 8px;
        }

        .gallery-slider-next {
            right: 8px;
        }

        .gallery-card {
            cursor: zoom-in;
        }

        .gallery-lightbox {
            position: fixed;
            inset: 0;
            background: rgba(10, 12, 20, 0.92);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 5000;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.25s ease;
            padding: 24px;
        }

        .gallery-lightbox.active {
            opacity: 1;
            pointer-events: auto;
        }

        .gallery-lightbox-panel {
            width: min(1100px, 100%);
            display: grid;
            grid-template-columns: 1.6fr 1fr;
            gap: 18px;
            background: #fff;
            border-radius: 22px;
            overflow: hidden;
        }

        .gallery-lightbox-image {
            background: #0f172a;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 420px;
            position: relative;
        }

        .gallery-lightbox-image img {
            max-width: 100%;
            max-height: 80vh;
            object-fit: contain;
        }

        .gallery-lightbox-content {
            padding: 28px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .gallery-lightbox-close,
        .gallery-lightbox-nav {
            border: none;
            cursor: pointer;
        }

        .gallery-lightbox-close {
            position: absolute;
            top: 14px;
            right: 14px;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.92);
            color: #111827;
            z-index: 2;
        }

        .gallery-lightbox-nav {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: var(--clr-primary);
            color: #fff;
        }

        .gallery-lightbox-actions {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        @media (max-width: 991px) {


            .gallery-slide {
                flex-basis: calc(33.333% - 14px);
            }

            .gallery-lightbox-panel {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 767px) {
            .gallery-slide {
                flex-basis: 100%;
            }
        }
    </style>




    <div class="gallery-lightbox" id="galleryLightbox" aria-hidden="true">
        <div class="gallery-lightbox-panel">
            <div class="gallery-lightbox-image">
                <button type="button" class="gallery-lightbox-close" onclick="closeGalleryLightbox()"
                    aria-label="Close">
                    <i class="fas fa-times"></i>
                </button>
                <img id="galleryLightboxImg" src="" alt="">
            </div>
            <div class="gallery-lightbox-content">
                <div>
                    <span class="section-badge"><i class="fas fa-camera"></i> Gallery Image</span>
                    <h3 id="galleryLightboxTitle"
                        style="font-family:var(--font-display);font-size:2rem;margin:14px 0 10px;"></h3>
                    <p id="galleryLightboxMeta" style="color:var(--clr-gray);margin-bottom:18px;"></p>
                </div>
                <div class="gallery-lightbox-actions">
                    <button type="button" class="gallery-lightbox-nav" onclick="navigateGallery(-1)"
                        aria-label="Previous image"><i class="fas fa-chevron-left"></i></button>
                    <button type="button" class="gallery-lightbox-nav" onclick="navigateGallery(1)"
                        aria-label="Next image"><i class="fas fa-chevron-right"></i></button>
                </div>
            </div>
        </div>
    </div>
@endsection
