@extends('layouts.frontend')

@section('content')

    {{-- HERO SLIDER --}}
    @if ($sliders->count())
        <section class="hero">
            <div class="hero-slider" id="heroSlider">
                @foreach ($sliders as $slider)
                    <div class="hero-slide">
                        <div class="hero-slide-bg" style="background-image: url('{{ $slider->image_url }}')"></div>
                        <div class="hero-slide-content">
                            <h1>{{ $slider->title }}</h1>
                            @if ($slider->subtitle)
                                <p>{{ $slider->subtitle }}</p>
                            @endif
                            @if ($slider->button_text)
                                <a href="{{ $slider->button_link ?? '#' }}" class="btn btn-primary">
                                    {{ $slider->button_text }} <i class="fas fa-arrow-right"></i>
                                </a>
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>
            @if ($sliders->count() > 1)
                <div class="hero-nav">
                    @foreach ($sliders as $i => $slider)
                        <button class="hero-dot {{ $i === 0 ? 'active' : '' }}"
                            onclick="goToSlide({{ $i }})"></button>
                    @endforeach
                </div>
            @endif
        </section>
    @endif

    {{-- PET GALLERY --}}
    @if ($galleries->count())
        <section class="section">
            <div class="container">
                <div class="section-header fade-up">
                    <span class="section-badge"><i class="fas fa-camera"></i> Our Friends</span>
                    <h2>Meet Our Adorable Pets</h2>
                    <p>Browse our gallery of lovable companions waiting to brighten your day</p>
                </div>
                <div class="gallery-slider-wrap">
                    <div class="gallery-slider" id="gallerySlider">
                        @foreach ($galleries as $gallery)
                            <div class="gallery-slide">
                                <div class="gallery-card fade-up" data-title="{{ $gallery->title }}"
                                    data-breed="{{ $gallery->breed }}">
                                    <img src="{{ $gallery->image_url }}" alt="{{ $gallery->title }}" loading="lazy">
                                    <div class="gallery-card-overlay">
                                        <h4>{{ $gallery->title }}</h4>
                                        @if ($gallery->breed)
                                            <span>{{ $gallery->breed }}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>

                    @if ($galleries->count() > 1)
                        <button class="gallery-slider-nav gallery-slider-prev" type="button"
                            onclick="moveGallerySlider(-1)"><i class="fas fa-chevron-left"></i></button>
                        <button class="gallery-slider-nav gallery-slider-next" type="button"
                            onclick="moveGallerySlider(1)"><i class="fas fa-chevron-right"></i></button>
                    @endif
                </div>
            </div>
        </section>
    @endif

    {{-- FEATURED BLOG SLIDER --}}
    @if (isset($featuredBlogs) && $featuredBlogs->count())
        <section class="section" style="background: var(--clr-light-gray);">
            <div class="container">
                <div class="section-header fade-up">
                    <span class="section-badge"><i class="fas fa-newspaper"></i> Featured Blog</span>
                    <h2>Latest Stories in Slide View</h2>
                    <p>Admin-selected blog posts highlighted in a rotating slider</p>
                </div>

                <div class="blog-slider-wrap">
                    <div class="blog-slider" id="blogSlider">
                        @foreach ($featuredBlogs as $blog)
                            <a href="{{ route('blog.detail', $blog->slug) }}" class="blog-slide">
                                <div class="blog-slide-image">
                                    <img src="{{ $blog->image_url }}" alt="{{ $blog->title }}" loading="lazy">
                                </div>
                                <div class="blog-slide-content">
                                    <div class="blog-card-date">{{ $blog->created_at->format('M d, Y') }}</div>
                                    <h3>{{ $blog->title }}</h3>
                                    <p>{{ $blog->excerpt }}</p>
                                    <span class="blog-card-link">Read More <i class="fas fa-arrow-right"></i></span>
                                </div>
                            </a>
                        @endforeach
                    </div>

                    @if ($featuredBlogs->count() > 1)
                        <button class="blog-slider-nav blog-slider-prev" type="button" onclick="moveBlogSlider(-1)"><i
                                class="fas fa-chevron-left"></i></button>
                        <button class="blog-slider-nav blog-slider-next" type="button" onclick="moveBlogSlider(1)"><i
                                class="fas fa-chevron-right"></i></button>
                    @endif
                </div>
            </div>
        </section>
    @endif

    {{-- PET CARE SERVICES --}}
    @if ($services->count())
        <section class="section" style="background: var(--clr-light-gray);">
            <div class="container">
                <div class="section-header fade-up">
                    <span class="section-badge"><i class="fas fa-heart"></i> What We Offer</span>
                    <h2>Premium Pet Care Services</h2>
                    <p>Everything your pet needs under one roof — from grooming to medical care</p>
                </div>
                <div class="services-grid">
                    @foreach ($services as $service)
                        <div class="service-card fade-up">
                            <div class="service-icon">
                                @if ($service->icon)
                                    <i class="{{ $service->icon }}"></i>
                                @else
                                    <i class="fas fa-paw"></i>
                                @endif
                            </div>
                            <h3>{{ $service->title }}</h3>
                            <p>{{ $service->short_description }}</p>
                            @if ($service->price)
                                <div class="service-price">From ₹{{ number_format($service->price) }}</div>
                            @endif
                            <a href="{{ route('service.show', $service->slug) }}"
                                style="display:inline-block;margin-top:12px;color:var(--clr-primary);font-weight:600;font-size:0.88rem;">
                                Learn More <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    @endforeach
                </div>
            </div>
        </section>
    @endif

    {{-- AVAILABLE CITIES --}}
    @if ($cities->count())
        <section class="section">
            <div class="container">
                <div class="section-header fade-up">
                    <span class="section-badge"><i class="fas fa-map-marker-alt"></i> Locations</span>
                    <h2>Available in Your City</h2>
                    <p>We're expanding to bring the best pet care closer to you</p>
                </div>
                <div class="cities-grid">
                    @foreach ($cities as $city)
                        <a href="{{ route('city.detail', $city->slug) }}" class="city-card fade-up"
                            style="text-decoration:none;color:inherit;display:block;">
                            @if ($city->image)
                                <img src="{{ $city->image_url }}" alt="{{ $city->name }}" loading="lazy">
                            @else
                                <div
                                    style="width:100%;height:100%;background:linear-gradient(135deg,var(--clr-primary),var(--clr-accent))">
                                </div>
                            @endif
                            <div class="city-card-content">
                                <h3>{{ $city->name }}</h3>
                                @if ($city->description)
                                    <p>{{ Str::limit($city->description, 60) }}</p>
                                @endif
                            </div>
                        </a>
                    @endforeach
                </div>
            </div>
        </section>
    @endif

    {{-- CTA SECTION --}}
    <section class="section" style="padding-bottom: 0;">
        <div class="cta-section fade-up">
            <h2>Give Your Pet the Best Care</h2>
            <p>Book a vaccination appointment today and keep your furry friend healthy and happy</p>
            <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap;">
                <a href="{{ route('vaccination') }}" class="btn btn-primary">
                    <i class="fas fa-syringe"></i> Book Vaccination
                </a>
                <a href="{{ route('adoption.index') }}" class="btn btn-white">
                    <i class="fas fa-heart"></i> Adopt a Pet
                </a>
                <a href="{{ route('contact') }}" class="btn btn-white">
                    <i class="fas fa-phone"></i> Contact Us
                </a>
            </div>
        </div>
    </section>

    {{-- FEATURED BLOGS --}}
    @if ($blogs->count())
        <section class="section">
            <div class="container">
                <div class="section-header fade-up">
                    <span class="section-badge"><i class="fas fa-newspaper"></i> Our Blog</span>
                    <h2>Pet Care Tips & Stories</h2>
                    <p>Expert advice and heartwarming stories from the world of pets</p>
                </div>

                <div class="blog-grid">
                    @foreach ($blogs as $blog)
                        <a href="{{ route('blog.detail', $blog->slug) }}" class="blog-card fade-up">
                            <div class="blog-card-img">
                                <img src="{{ $blog->image_url }}" alt="{{ $blog->title }}" loading="lazy">
                            </div>
                            <div class="blog-card-body">
                                <div class="blog-card-date">{{ $blog->created_at->format('M d, Y') }}</div>
                                <h3>{{ $blog->title }}</h3>
                                <p>{{ $blog->excerpt }}</p>
                                <span class="blog-card-link">Read More <i class="fas fa-arrow-right"></i></span>
                            </div>
                        </a>
                    @endforeach
                </div>
                <div style="text-align:center;margin-top:40px;">
                    <a href="{{ route('blogs') }}" class="btn btn-outline">View All Posts <i
                            class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </section>
    @endif



    {{-- MAIN BLOG GRID TO SLIDER --}}
    @if ($blogs->count())
        <section class="section">
            <div class="container">
                <div class="section-header fade-up">
                    <span class="section-badge"><i class="fas fa-newspaper"></i> Our Blog</span>
                    <h2>Pet Care Tips & Stories</h2>
                    <p>Expert advice and heartwarming stories from the world of pets</p>
                </div>

                <div class="main-blog-slider-outer">
                    <div class="main-blog-slider-inner" id="mainBlogGrid">
                        @foreach ($blogs as $blog)
                            <div class="main-blog-item">
                                <a href="{{ route('blog.detail', $blog->slug) }}" class="blog-card fade-up">
                                    <div class="blog-card-img">
                                        <img src="{{ $blog->image_url }}" alt="{{ $blog->title }}" loading="lazy">
                                    </div>
                                    <div class="blog-card-body">
                                        <div class="blog-card-date">{{ $blog->created_at->format('M d, Y') }}</div>
                                        <h3>{{ $blog->title }}</h3>
                                        <p>{{ $blog->excerpt }}</p>
                                        <span class="blog-card-link">Read More <i class="fas fa-arrow-right"></i></span>
                                    </div>
                                </a>
                            </div>
                        @endforeach
                    </div>

                    {{-- Slider Controls --}}
                    @if ($blogs->count() > 1)
                        <button class="grid-nav-btn prev" onclick="shiftGrid(-1)"><i
                                class="fas fa-chevron-left"></i></button>
                        <button class="grid-nav-btn next" onclick="shiftGrid(1)"><i
                                class="fas fa-chevron-right"></i></button>
                    @endif
                </div>

                <div style="text-align:center;margin-top:40px;">
                    <a href="{{ route('blogs') }}" class="btn btn-outline">View All Posts <i
                            class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </section>
    @endif
@endsection




@section('scripts')
    <script>
        // Hero Slider
        let currentSlide = 0;
        const slider = document.getElementById('heroSlider');
        const dots = document.querySelectorAll('.hero-dot');
        const totalSlides = {{ $sliders->count() }};

        function goToSlide(index) {
            currentSlide = index;
            if (slider) {
                slider.style.transform = `translateX(-${index * 100}%)`;
            }
            dots.forEach((dot, i) => dot.classList.toggle('active', i === index));
        }

        if (totalSlides > 1) {
            setInterval(() => {
                goToSlide((currentSlide + 1) % totalSlides);
            }, 5500);
        }

        // Featured blog slider
        const blogSlider = document.getElementById('blogSlider');
        let blogSlideIndex = 0;
        const blogSlides = blogSlider ? blogSlider.querySelectorAll('.blog-slide') : [];

        function moveBlogSlider(direction) {
            if (!blogSlider || !blogSlides.length) return;
            const visibleCount = window.innerWidth >= 992 ? 2 : 1;
            const maxIndex = Math.max(0, blogSlides.length - visibleCount);
            blogSlideIndex = Math.min(maxIndex, Math.max(0, blogSlideIndex + direction));
            blogSlider.style.transform = `translateX(-${blogSlideIndex * (100 / visibleCount)}%)`;
        }

        if (blogSlider && blogSlides.length > 1) {
            window.addEventListener('resize', () => moveBlogSlider(0));
        }

        // Gallery slider
        const gallerySlider = document.getElementById('gallerySlider');
        let gallerySlideIndex = 0;
        const gallerySlides = gallerySlider ? gallerySlider.querySelectorAll('.gallery-slide') : [];

        function moveGallerySlider(direction) {
            if (!gallerySlider || !gallerySlides.length) return;
            const visibleCount = window.innerWidth >= 1200 ? 4 : (window.innerWidth >= 768 ? 3 : 1);
            const maxIndex = Math.max(0, gallerySlides.length - visibleCount);
            gallerySlideIndex = Math.min(maxIndex, Math.max(0, gallerySlideIndex + direction));
            gallerySlider.style.transform = `translateX(-${gallerySlideIndex * (100 / visibleCount)}%)`;
        }

        if (gallerySlider && gallerySlides.length > 1) {
            window.addEventListener('resize', () => moveGallerySlider(0));
        }

        // Gallery lightbox
        const galleryItems = Array.from(document.querySelectorAll('.gallery-card'));
        const lightbox = document.getElementById('galleryLightbox');
        const lightboxImg = document.getElementById('galleryLightboxImg');
        const lightboxTitle = document.getElementById('galleryLightboxTitle');
        const lightboxMeta = document.getElementById('galleryLightboxMeta');
        let currentGalleryIndex = 0;

        function openGalleryLightbox(index) {
            if (!lightbox || !lightboxImg) return;
            currentGalleryIndex = index;
            renderGalleryLightbox();
            lightbox.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function renderGalleryLightbox() {
            const item = galleryItems[currentGalleryIndex];
            if (!item || !lightboxImg) return;
            const img = item.querySelector('img');
            const title = item.dataset.title || '';
            const breed = item.dataset.breed || '';
            lightboxImg.src = img ? img.src : '';
            lightboxImg.alt = title;
            if (lightboxTitle) lightboxTitle.textContent = title;
            if (lightboxMeta) lightboxMeta.textContent = breed;
        }

        function closeGalleryLightbox() {
            if (!lightbox) return;
            lightbox.classList.remove('active');
            document.body.style.overflow = '';
        }

        function navigateGallery(direction) {
            if (!galleryItems.length) return;
            currentGalleryIndex = (currentGalleryIndex + direction + galleryItems.length) % galleryItems.length;
            renderGalleryLightbox();
        }

        galleryItems.forEach((item, index) => {
            item.addEventListener('click', () => openGalleryLightbox(index));
        });

        window.openGalleryLightbox = openGalleryLightbox;
        window.closeGalleryLightbox = closeGalleryLightbox;
        window.navigateGallery = navigateGallery;
        window.moveBlogSlider = moveBlogSlider;
        window.moveGallerySlider = moveGallerySlider;
    </script>

    <script>
        let currentGridPos = 0;

function shiftGrid(dir) {
    const container = document.getElementById('mainBlogGrid');
    const items = container.querySelectorAll('.main-blog-item');

    if (!container || !items.length) return;

    let itemsInView = 3;
    if (window.innerWidth <= 991) itemsInView = 2;
    if (window.innerWidth <= 767) itemsInView = 1;

    const itemWidth = items[0].offsetWidth + 24; // gap
    const totalItems = items.length / 2; // because duplicated

    currentGridPos += dir;

    container.style.transition = "transform 0.5s ease";
    container.style.transform = `translateX(-${currentGridPos * itemWidth}px)`;

    // RESET for infinite effect
    if (currentGridPos >= totalItems) {
        setTimeout(() => {
            container.style.transition = "none";
            currentGridPos = 0;
            container.style.transform = `translateX(0px)`;
        }, 500);
    }

    if (currentGridPos < 0) {
        container.style.transition = "none";
        currentGridPos = totalItems - 1;
        container.style.transform = `translateX(-${currentGridPos * itemWidth}px)`;
    }
}

        // Auto-slide functionality
        let gridAutoSlide = setInterval(() => shiftGrid(1), 5000);

        // Mouse enter par ruk jaye, leave par phir shuru ho jaye
        const sliderOuter = document.querySelector('.main-blog-slider-outer');
        if (sliderOuter) {
            sliderOuter.addEventListener('mouseenter', () => clearInterval(gridAutoSlide));
            sliderOuter.addEventListener('mouseleave', () => {
                clearInterval(gridAutoSlide);
                gridAutoSlide = setInterval(() => shiftGrid(1), 5000);
            });
        }

        // Window resize hone par position reset karein taaki layout na bigde
        window.addEventListener('resize', () => {
            currentGridPos = 0;
            document.getElementById('mainBlogGrid').style.transform = `translateX(0)`;
        });
    </script>

    <style>
        .blog-slider-wrap {
            position: relative;
            overflow: hidden;
            border-radius: var(--radius-lg);
        }

        .blog-slider {
            display: flex;
            gap: 24px;
            transition: transform 0.55s ease;
            will-change: transform;
        }

        .blog-slide {
            flex: 0 0 calc(50% - 12px);
            background: white;
            border-radius: var(--radius-lg);
            overflow: hidden;
            border: 1px solid var(--clr-border);
            display: grid;
            grid-template-columns: 1fr 1fr;
            min-height: 320px;
            text-decoration: none;
            color: inherit;
        }

        .blog-slide-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .blog-slide-content {
            padding: 28px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .blog-slider-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 46px;
            height: 46px;
            border: none;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.95);
            box-shadow: var(--shadow-md);
            color: var(--clr-secondary);
            cursor: pointer;
            z-index: 2;
        }

        .blog-slider-prev {
            left: 12px;
        }

        .blog-slider-next {
            right: 12px;
        }

        .gallery-slider-wrap {
            position: relative;
            overflow: hidden;
            border-radius: var(--radius-lg);
        }

        .gallery-slider {
            display: flex;
            gap: 20px;
            transition: transform 0.55s ease;
            will-change: transform;
        }

        .gallery-slide {
            flex: 0 0 calc(25% - 15px);
            min-width: 0;
        }

        .gallery-slider-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 42px;
            height: 42px;
            border: none;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.95);
            box-shadow: var(--shadow-md);
            color: var(--clr-secondary);
            cursor: pointer;
            z-index: 3;
        }

        .gallery-slider-prev {
            left: 8px;
        }

        .gallery-slider-next {
            right: 8px;
        }

        .gallery-card {
            cursor: zoom-in;
        }

        .gallery-lightbox {
            position: fixed;
            inset: 0;
            background: rgba(10, 12, 20, 0.92);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 5000;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.25s ease;
            padding: 24px;
        }

        .gallery-lightbox.active {
            opacity: 1;
            pointer-events: auto;
        }

        .gallery-lightbox-panel {
            width: min(1100px, 100%);
            display: grid;
            grid-template-columns: 1.6fr 1fr;
            gap: 18px;
            background: #fff;
            border-radius: 22px;
            overflow: hidden;
        }

        .gallery-lightbox-image {
            background: #0f172a;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 420px;
            position: relative;
        }

        .gallery-lightbox-image img {
            max-width: 100%;
            max-height: 80vh;
            object-fit: contain;
        }

        .gallery-lightbox-content {
            padding: 28px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .gallery-lightbox-close,
        .gallery-lightbox-nav {
            border: none;
            cursor: pointer;
        }

        .gallery-lightbox-close {
            position: absolute;
            top: 14px;
            right: 14px;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.92);
            color: #111827;
            z-index: 2;
        }

        .gallery-lightbox-nav {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: var(--clr-primary);
            color: #fff;
        }

        .gallery-lightbox-actions {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        @media (max-width: 991px) {
            .blog-slide {
                flex-basis: 100%;
                grid-template-columns: 1fr;
            }

            .gallery-slide {
                flex-basis: calc(33.333% - 14px);
            }

            .gallery-lightbox-panel {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 767px) {
            .gallery-slide {
                flex-basis: 100%;
            }
        }
    </style>


    <style>
        /* Unique Styles for Main Blog Slider */
        .main-blog-slider-outer {
            position: relative;
            overflow: hidden;
            /* Bahar ke cards chhupane ke liye */
            padding: 10px 5px;
        }

.blog-card {
    background: #fff;
    border: 1px solid #eee;
    border-radius: 16px;
    overflow: hidden;
    transition: 0.3s ease;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}

.blog-card:hover {
    transform: translateY(-6px);
    box-shadow: 0 12px 25px rgba(0,0,0,0.12);
}

.blog-card-img img {
    width: 100%;
    height: 220px;
    object-fit: cover;
    border-top-left-radius: 16px;
    border-top-right-radius: 16px;
}

.blog-card-body {
    padding: 18px;
}

        .main-blog-slider-inner {
            display: flex;
            gap: 24px;
            transition: transform 0.5s ease-in-out;
        }

        .grid-nav-btn {
            top: 40%;
            transform: translateY(-50%);
        }

        .main-blog-item {
            flex: 0 0 calc((100% - 48px) / 3);
            /* 3 cards with gap */
        }

        .grid-nav-btn {
            position: absolute;
            top: 45%;
            width: 45px;
            height: 45px;
            background: #fff;
            border: none;
            border-radius: 50%;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            color: var(--clr-primary);
            cursor: pointer;
            z-index: 10;
            transition: 0.3s;
        }

        .grid-nav-btn:hover {
            background: var(--clr-primary);
            color: #fff;
        }

        .grid-nav-btn.prev {
            left: 5px;
        }

        .grid-nav-btn.next {
            right: 5px;
        }

        @media (max-width: 991px) {
            .main-blog-item {
                flex: 0 0 calc((100% - 24px) / 2);
            }
        }

        @media (max-width: 767px) {
            .main-blog-item {
                flex: 0 0 100%;
            }
        }
    </style>

    <div class="gallery-lightbox" id="galleryLightbox" aria-hidden="true">
        <div class="gallery-lightbox-panel">
            <div class="gallery-lightbox-image">
                <button type="button" class="gallery-lightbox-close" onclick="closeGalleryLightbox()"
                    aria-label="Close">
                    <i class="fas fa-times"></i>
                </button>
                <img id="galleryLightboxImg" src="" alt="">
            </div>
            <div class="gallery-lightbox-content">
                <div>
                    <span class="section-badge"><i class="fas fa-camera"></i> Gallery Image</span>
                    <h3 id="galleryLightboxTitle"
                        style="font-family:var(--font-display);font-size:2rem;margin:14px 0 10px;"></h3>
                    <p id="galleryLightboxMeta" style="color:var(--clr-gray);margin-bottom:18px;"></p>
                </div>
                <div class="gallery-lightbox-actions">
                    <button type="button" class="gallery-lightbox-nav" onclick="navigateGallery(-1)"
                        aria-label="Previous image"><i class="fas fa-chevron-left"></i></button>
                    <button type="button" class="gallery-lightbox-nav" onclick="navigateGallery(1)"
                        aria-label="Next image"><i class="fas fa-chevron-right"></i></button>
                </div>
            </div>
        </div>
    </div>
@endsection
