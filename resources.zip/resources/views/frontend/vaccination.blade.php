@extends('layouts.frontend')

@section('meta_title', 'Book Pet Vaccination - ' . $settings['site_name'])
@section('meta_description', 'Book a vaccination appointment for your pet. We offer all types of pet vaccinations across multiple cities.')

@section('styles')
<style>
/* ═══════════════════════════════════════════
   VACCINATION PAGE STYLES
═══════════════════════════════════════════ */

/* ── Hero ── */
.vac-hero {
    background: linear-gradient(135deg, var(--clr-secondary) 0%, #2D1B69 60%, var(--clr-dark) 100%);
    padding: 72px 0 80px;
    position: relative;
    overflow: hidden;
}
.vac-hero::before {
    content: '';
    position: absolute; inset: 0;
    background: radial-gradient(ellipse 60% 80% at 80% 50%, rgba(255,107,53,0.18) 0%, transparent 70%);
    pointer-events: none;
}
.vac-hero-inner {
    display: grid;
    grid-template-columns: 1fr auto;
    align-items: center;
    gap: 40px;
}
.vac-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: rgba(255,107,53,0.15);
    border: 1px solid rgba(255,107,53,0.3);
    color: var(--clr-primary);
    font-size: 0.8rem;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    padding: 6px 14px;
    border-radius: 999px;
    margin-bottom: 18px;
}
.vac-hero h1 {
    font-family: var(--font-display);
    font-size: clamp(2rem, 4vw, 2.8rem);
    color: #fff;
    margin-bottom: 14px;
    line-height: 1.15;
}
.vac-hero-sub {
    color: rgba(255,255,255,0.65);
    font-size: 1rem;
    max-width: 480px;
    line-height: 1.65;
    margin-bottom: 28px;
}
.vac-breadcrumb {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.85rem;
    color: rgba(255,255,255,0.5);
}
.vac-breadcrumb a { color: rgba(255,255,255,0.7); text-decoration: none; transition: color 0.2s; }
.vac-breadcrumb a:hover { color: var(--clr-primary); }
.vac-breadcrumb i { font-size: 0.65rem; }
.vac-hero-visual {
    width: 160px;
    height: 160px;
    border-radius: 50%;
    background: rgba(255,255,255,0.06);
    border: 2px solid rgba(255,255,255,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 5rem;
    flex-shrink: 0;
}

/* ── Trust bar ── */
.vac-trust-bar {
    background: white;
    border-bottom: 1px solid var(--clr-border);
    padding: 18px 0;
}
.vac-trust-list {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 40px;
    flex-wrap: wrap;
}
.vac-trust-item {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--clr-secondary);
}
.vac-trust-item i {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.9rem;
    flex-shrink: 0;
}
.vac-trust-item.orange i { background: var(--clr-warm); color: var(--clr-primary); }
.vac-trust-item.green  i { background: #ECFDF5; color: #059669; }
.vac-trust-item.blue   i { background: #EFF6FF; color: #3B82F6; }
.vac-trust-item.purple i { background: #F5F3FF; color: #7C3AED; }

/* ── Page layout ── */
.vac-page {
    padding: 60px 0 80px;
    background: #F8F9FC;
}
.vac-grid {
    display: grid;
    grid-template-columns: 1fr 380px;
    gap: 32px;
    align-items: start;
}

/* ── Form card ── */
.vac-card {
    background: #fff;
    border-radius: 20px;
    box-shadow: 0 2px 20px rgba(0,0,0,0.06);
    overflow: hidden;
}
.vac-card-header {
    background: linear-gradient(135deg, var(--clr-primary), #FF8C5A);
    padding: 28px 32px;
    color: white;
}
.vac-card-header h2 {
    font-family: var(--font-display);
    font-size: 1.5rem;
    margin-bottom: 6px;
    color: #fff;
}
.vac-card-header p {
    opacity: 0.85;
    font-size: 0.9rem;
}
.vac-card-body { padding: 32px; }

/* ── Step indicator ── */
.vac-steps {
    display: flex;
    align-items: center;
    margin-bottom: 32px;
    gap: 0;
}
.vac-step {
    display: flex;
    align-items: center;
    gap: 10px;
    flex: 1;
}
.vac-step-num {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: var(--clr-warm);
    color: var(--clr-primary);
    font-size: 0.85rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: all 0.3s;
}
.vac-step.active .vac-step-num {
    background: var(--clr-primary);
    color: white;
    box-shadow: 0 0 0 4px rgba(255,107,53,0.2);
}
.vac-step-label {
    font-size: 0.8rem;
    font-weight: 600;
    color: var(--clr-gray);
}
.vac-step.active .vac-step-label { color: var(--clr-primary); }
.vac-step-line {
    flex: 1;
    height: 2px;
    background: var(--clr-border);
    margin: 0 8px;
}

/* ── Notices ── */
.vac-notice {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 14px 18px;
    border-radius: 12px;
    margin-bottom: 24px;
    font-size: 0.88rem;
    line-height: 1.5;
}
.vac-notice.blue  { background: #EFF6FF; border: 1px solid #BFDBFE; color: #1E40AF; }
.vac-notice.amber { background: #FFFBEB; border: 1px solid #FDE68A; color: #92400E; }
.vac-notice i { margin-top: 2px; flex-shrink: 0; }
.vac-fee-badge {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: linear-gradient(135deg, var(--clr-warm), #FFF3EE);
    border: 1px solid rgba(255,107,53,0.2);
    border-radius: 12px;
    padding: 16px 20px;
    margin-bottom: 28px;
}
.vac-fee-label { font-size: 0.9rem; color: var(--clr-gray); display: flex; align-items: center; gap: 8px; }
.vac-fee-amount { font-size: 1.6rem; font-weight: 800; color: var(--clr-primary); }

/* ── Form section titles ── */
.vac-form-section {
    border-top: 1px solid var(--clr-border);
    padding-top: 24px;
    margin-top: 8px;
    margin-bottom: 20px;
}
.vac-form-section-title {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 0.78rem;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--clr-gray);
    margin-bottom: 18px;
}
.vac-form-section-title::after {
    content: '';
    flex: 1;
    height: 1px;
    background: var(--clr-border);
}

/* ── Form fields ── */
.vac-field { margin-bottom: 20px; }
.vac-field label {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 0.83rem;
    font-weight: 600;
    color: var(--clr-secondary);
    margin-bottom: 7px;
}
.vac-field label .req { color: var(--clr-primary); font-size: 0.9rem; line-height: 1; }
.vac-field label .tag {
    font-size: 0.72rem;
    font-weight: 500;
    background: #EFF6FF;
    color: #3B82F6;
    padding: 1px 7px;
    border-radius: 99px;
}
.vac-input {
    width: 100%;
    padding: 11px 14px;
    border: 1.5px solid var(--clr-border);
    border-radius: 10px;
    font-family: var(--font-body);
    font-size: 0.92rem;
    color: var(--clr-secondary);
    background: #FAFAFA;
    transition: border-color 0.2s, box-shadow 0.2s, background 0.2s;
    -webkit-appearance: none;
    appearance: none;
}
.vac-input:focus {
    outline: none;
    border-color: var(--clr-primary);
    box-shadow: 0 0 0 3.5px rgba(255,107,53,0.12);
    background: #fff;
}
select.vac-input {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%236B7280' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 12px center;
    padding-right: 36px;
    cursor: pointer;
}
.vac-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}
.vac-input-group {
    display: flex;
    gap: 10px;
    align-items: flex-start;
}
.vac-input-group .vac-input { flex: 1; }

/* ── OTP row ── */
#v_otpRow { display: none; }
.otp-input {
    letter-spacing: 8px;
    font-size: 1.3rem;
    text-align: center;
    font-weight: 700;
}
#v_otpMsg { font-size: 0.82rem; margin-top: 6px; display: block; }

/* ── Verified badge ── */
#v_verifiedBadge {
    display: none;
    background: #ECFDF5;
    border: 1px solid #A7F3D0;
    padding: 11px 16px;
    border-radius: 10px;
    margin-bottom: 20px;
    font-size: 0.88rem;
    font-weight: 600;
    color: #065F46;
    align-items: center;
    gap: 8px;
}

/* ── Error box ── */
#v_bookingError {
    display: none;
    background: #FEF2F2;
    color: #991B1B;
    padding: 14px 18px;
    border-radius: 10px;
    border: 1px solid #FECACA;
    margin-bottom: 20px;
    font-size: 0.88rem;
    line-height: 1.5;
}

/* ── Submit button ── */
.vac-submit-btn {
    width: 100%;
    justify-content: center;
    padding: 15px 24px;
    font-size: 1rem;
    border-radius: 12px;
    font-weight: 700;
    letter-spacing: 0.02em;
}

/* ── Success state ── */
#vac-step2 {
    display: none;
    text-align: center;
    padding: 56px 24px;
}
.vac-success-icon {
    width: 88px;
    height: 88px;
    border-radius: 50%;
    background: linear-gradient(135deg, #ECFDF5, #D1FAE5);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 24px;
    font-size: 2.5rem;
    color: #059669;
    box-shadow: 0 0 0 12px rgba(5,150,105,0.08);
}
#vac-step2 h3 {
    font-family: var(--font-display);
    font-size: 1.6rem;
    color: var(--clr-secondary);
    margin-bottom: 10px;
}
#vac-step2 p { color: var(--clr-gray); max-width: 340px; margin: 0 auto 28px; line-height: 1.6; }

/* ═══════════════════════════════════════════
   SIDEBAR
═══════════════════════════════════════════ */
.vac-sidebar { display: flex; flex-direction: column; gap: 24px; }

/* Why Vaccinate card */
.why-card {
    background: #fff;
    border-radius: 20px;
    box-shadow: 0 2px 20px rgba(0,0,0,0.06);
    overflow: hidden;
}
.why-card-header {
    padding: 22px 26px 18px;
    border-bottom: 1px solid var(--clr-border);
    display: flex;
    align-items: center;
    gap: 12px;
}
.why-card-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: var(--clr-warm);
    color: var(--clr-primary);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
}
.why-card-header h3 {
    font-size: 1rem;
    font-weight: 700;
    color: var(--clr-secondary);
    margin: 0;
}
.why-list { padding: 20px 26px; display: flex; flex-direction: column; gap: 16px; }
.why-item {
    display: flex;
    gap: 14px;
    align-items: flex-start;
}
.why-item-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    font-size: 0.95rem;
}
.why-item-icon.orange { background: var(--clr-warm); color: var(--clr-primary); }
.why-item-icon.green  { background: #ECFDF5; color: #059669; }
.why-item-icon.blue   { background: #EFF6FF; color: #3B82F6; }
.why-item-icon.purple { background: #F5F3FF; color: #7C3AED; }
.why-item-text h4 { font-size: 0.9rem; margin-bottom: 3px; color: var(--clr-secondary); }
.why-item-text p { font-size: 0.82rem; color: var(--clr-gray); line-height: 1.55; margin: 0; }

/* Stats strip */
.vac-stats {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 2px 20px rgba(0,0,0,0.06);
    padding: 20px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
}
.vac-stat {
    background: var(--clr-warm);
    border-radius: 12px;
    padding: 16px;
    text-align: center;
}
.vac-stat-num { font-size: 1.5rem; font-weight: 800; color: var(--clr-primary); font-family: var(--font-display); }
.vac-stat-label { font-size: 0.72rem; color: var(--clr-gray); font-weight: 600; margin-top: 2px; }

/* Help card */
.help-card {
    background: linear-gradient(135deg, var(--clr-secondary) 0%, #2D1B69 100%);
    border-radius: 20px;
    padding: 28px;
    color: white;
}
.help-card h3 { font-size: 1.05rem; margin-bottom: 10px; color: #fff; display: flex; align-items: center; gap: 8px; }
.help-card p { opacity: 0.75; font-size: 0.88rem; line-height: 1.55; margin-bottom: 20px; }
.btn-white-outline {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    width: 100%;
    padding: 12px 20px;
    border: 1.5px solid rgba(255,255,255,0.35);
    border-radius: 10px;
    color: white;
    font-weight: 600;
    font-size: 0.9rem;
    text-decoration: none;
    transition: background 0.2s, border-color 0.2s;
    margin-bottom: 10px;
}
.btn-white-outline:hover { background: rgba(255,255,255,0.12); border-color: rgba(255,255,255,0.6); color: white; }
.btn-whatsapp {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    width: 100%;
    padding: 12px 20px;
    background: #25D366;
    border: none;
    border-radius: 10px;
    color: white;
    font-weight: 600;
    font-size: 0.9rem;
    text-decoration: none;
    transition: background 0.2s;
}
.btn-whatsapp:hover { background: #1DAA52; color: white; }

/* ═══════════════════════════════════════════
   RESPONSIVE
═══════════════════════════════════════════ */
@media (max-width: 960px) {
    .vac-grid {
        grid-template-columns: 1fr;
    }
    .vac-sidebar {
        /* Show sidebar before form on mobile */
        order: 3;
    }
    .vac-sidebar .why-card { display: none; } /* hide on mobile to save space */
    .vac-hero-visual { display: none; }
    .vac-hero-inner { grid-template-columns: 1fr; }
    .vac-trust-list { gap: 20px 32px; }
}
@media (max-width: 640px) {
    .vac-hero { padding: 48px 0 56px; }
    .vac-card-body { padding: 20px; }
    .vac-row { grid-template-columns: 1fr; gap: 0; }
    .vac-page { padding: 32px 0 60px; }
    .vac-card-header { padding: 22px 20px; }
    .vac-stats { grid-template-columns: 1fr 1fr; }
    .vac-trust-list { gap: 14px 24px; }
    .vac-trust-item span { display: none; }
    .vac-input { font-size: 16px; } /* prevent iOS zoom */
    .vac-input-group { flex-direction: column; }
    .vac-input-group .vac-input { width: 100%; }
    #v_sendOtpBtn { width: 100%; justify-content: center; }
}
@media (max-width: 480px) {
    .vac-steps { display: none; }
    .vac-form-section-title { font-size: 0.72rem; }
}
</style>
@endsection

@section('content')
@php
    $waNumber = preg_replace('/[^0-9]/', '', $settings['whatsapp_number'] ?? '');
    $waVaccinationUrl = $waNumber
        ? 'https://wa.me/' . $waNumber . '?text=' . urlencode('Hey, I want help')
        : route('contact');
@endphp

<div class="page-hero">
    <div class="container">
         <h1>Book Vaccination</h1>
        <div class="breadcrumb">
            <a href="{{ route('home') }}">Home</a> / Vaccination Booking
        </div>
    </div>
</div>


{{-- ═══ TRUST BAR ═══ --}}
<div class="vac-trust-bar">
    <div class="container">
        <div class="vac-trust-list">
            <div class="vac-trust-item orange">
                <i class="fas fa-shield-alt"></i>
                <span>Certified Vets</span>
            </div>
            <div class="vac-trust-item green">
                <i class="fas fa-clock"></i>
                <span>24h Confirmation</span>
            </div>
            <div class="vac-trust-item blue">
                <i class="fas fa-map-marker-alt"></i>
                <span>Multiple Cities</span>
            </div>
            <div class="vac-trust-item purple">
                <i class="fas fa-heart"></i>
                <span>1000+ Happy Pets</span>
            </div>
        </div>
    </div>
</div>

{{-- ═══ MAIN CONTENT ═══ --}}
<div class="vac-page">
    <div class="container">
        <div class="vac-grid">

            {{-- ──────── BOOKING FORM CARD ──────── --}}
            <div class="vac-card fade-up">
                <div class="vac-card-header">
                    <h2><i class="fab fa-whatsapp" style="margin-right:10px;"></i>Book on WhatsApp</h2>
                    <p>Skip long forms. Start a direct chat and get immediate guidance from our team.</p>
                </div>
                <div class="vac-card-body">
                    <div class="vac-notice blue">
                        <i class="fas fa-bolt"></i>
                        <span>Quick booking in under 1 minute. Share your pet details on WhatsApp and our team will guide you instantly.</span>
                    </div>

                    <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:22px;">
                        <a href="{{ $waVaccinationUrl }}" target="_blank" rel="noopener" class="btn btn-primary" style="flex:1;justify-content:center;min-width:220px;">
                            <i class="fab fa-whatsapp"></i> Start WhatsApp Chat
                        </a>
                        @if ($settings['site_phone'])
                        <a href="tel:{{ $settings['site_phone'] }}" class="btn btn-outline" style="flex:1;justify-content:center;min-width:220px;">
                            <i class="fas fa-phone"></i> Call Us
                        </a>
                        @endif
                    </div>

                    <div class="vac-form-section">
                        <div class="vac-form-section-title"><i class="fas fa-list-check"></i> How It Works</div>
                    </div>

                    <div class="vac-steps" style="margin-bottom:0;">
                        <div class="vac-step active">
                            <div class="vac-step-num">1</div>
                            <div class="vac-step-label">Open Chat</div>
                        </div>
                        <div class="vac-step-line"></div>
                        <div class="vac-step active">
                            <div class="vac-step-num">2</div>
                            <div class="vac-step-label">Share Pet Info</div>
                        </div>
                        <div class="vac-step-line"></div>
                        <div class="vac-step active">
                            <div class="vac-step-num">3</div>
                            <div class="vac-step-label">Get Slot Confirmed</div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- ──────── SIDEBAR ──────── --}}
            <div class="vac-sidebar fade-up" style="animation-delay:0.15s;">

                {{-- Stats --}}
                <div class="vac-stats">
                    <div class="vac-stat">
                        <div class="vac-stat-num">1000+</div>
                        <div class="vac-stat-label">Pets Vaccinated</div>
                    </div>
                    <div class="vac-stat">
                        <div class="vac-stat-num">50+</div>
                        <div class="vac-stat-label">Vaccine Types</div>
                    </div>
                    <div class="vac-stat">
                        <div class="vac-stat-num">{{ $cities->count() }}+</div>
                        <div class="vac-stat-label">Cities Covered</div>
                    </div>
                    <div class="vac-stat">
                        <div class="vac-stat-num">24h</div>
                        <div class="vac-stat-label">Confirmation</div>
                    </div>
                </div>

                {{-- Why Vaccinate --}}
                <div class="why-card">
                    <div class="why-card-header">
                        <div class="why-card-icon"><i class="fas fa-syringe"></i></div>
                        <h3>Why Vaccinate Your Pet?</h3>
                    </div>
                    <div class="why-list">
                        <div class="why-item">
                            <div class="why-item-icon orange"><i class="fas fa-shield-alt"></i></div>
                            <div class="why-item-text">
                                <h4>Disease Prevention</h4>
                                <p>Protect your pet from deadly diseases like rabies, distemper, and parvovirus.</p>
                            </div>
                        </div>
                        <div class="why-item">
                            <div class="why-item-icon green"><i class="fas fa-heart"></i></div>
                            <div class="why-item-text">
                                <h4>Longer, Healthier Life</h4>
                                <p>Regular vaccinations help ensure your pet lives a long and healthy life.</p>
                            </div>
                        </div>
                        <div class="why-item">
                            <div class="why-item-icon blue"><i class="fas fa-users"></i></div>
                            <div class="why-item-text">
                                <h4>Public Safety</h4>
                                <p>Vaccinated pets help prevent the spread of diseases to other animals and humans.</p>
                            </div>
                        </div>
                        <div class="why-item">
                            <div class="why-item-icon purple"><i class="fas fa-certificate"></i></div>
                            <div class="why-item-text">
                                <h4>Vaccination Record</h4>
                                <p>You receive an official vaccination record certificate for your pet after each visit.</p>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Help card --}}
                <div class="help-card">
                    <h3><i class="fas fa-headset"></i> Need Help?</h3>
                    <p>Our team is available to answer your questions about pet vaccinations and help you choose the right schedule.</p>
                    @if ($settings['site_phone'])
                    <a href="tel:{{ $settings['site_phone'] }}" class="btn-white-outline">
                        <i class="fas fa-phone"></i> {{ $settings['site_phone'] }}
                    </a>
                    @endif
                    @if ($settings['whatsapp_number'])
                    <a href="https://wa.me/{{ preg_replace('/\D/', '', $settings['whatsapp_number']) }}" target="_blank" rel="noopener" class="btn-whatsapp">
                        <i class="fab fa-whatsapp"></i> Chat on WhatsApp
                    </a>
                    @endif
                </div>

            </div>
        </div>
    </div>
</div>

@endsection
